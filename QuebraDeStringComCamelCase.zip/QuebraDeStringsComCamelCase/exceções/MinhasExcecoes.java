
public class MinhasExcecoes extends RuntimeException {

	public MinhasExcecoes(String mensagem) {
		super(mensagem);
	}
}
