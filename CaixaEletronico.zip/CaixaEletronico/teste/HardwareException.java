
public class HardwareException extends Exception {

	public HardwareException(String message) {
		super(message);
	}
}
