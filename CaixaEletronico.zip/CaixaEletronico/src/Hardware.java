
public interface Hardware {

	void lerEnvelope() throws HardwareException;

	void entregarDinheiro() throws HardwareException;

	String pegarNumeroDaContaCartão() throws HardwareException;

}
